﻿using System.Windows;

namespace KMA.ProgrammingInCSharp2022.Practice3LoginControlMVVM
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
