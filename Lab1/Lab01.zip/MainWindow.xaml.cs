﻿using System.Windows;

namespace KMA.ProgrammingInCSharp2022.Practice3LoginControlMVVM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //var signInWindow = new SignInWindow();
            //signInWindow.ShowDialog();
        }
    }
}
